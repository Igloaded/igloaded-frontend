const formatNum = (num) => {
	return num.toLocaleString('en-IN');
};

const loading =
	document.getElementById('loading');
const main = document.getElementById('main');
const authenticate = document.getElementById(
	'authenticate'
);
const menuBtn =
	document.getElementById('menuBtn');
const greetLabel =
	document.getElementById('greetLabel');
const usernameLbl = document.getElementById(
	'usernameLbl'
);
const logout = document.getElementById('logout');
const logoutDiv = document.getElementById(
	'confirmLogout'
);
const noBtn = document.getElementById('noBtn');
const yesBtn = document.getElementById('yesBtn');
const refresh = document.getElementsByClassName(
	'icon-refresh'
)[0];

const followers =
	document.getElementById('follower');

const followings =
	document.getElementById('following');

const posts = document.getElementById('post');

const requests =
	document.getElementById('request');

const output = document.getElementById('output');

let igusername = '';

function rotateIcon() {
	refresh.classList.add('rotate');
	setTimeout(() => {
		refresh.classList.remove('rotate');
	}, 1000);
}

logout.addEventListener('click', function (e) {
	logoutDiv.style.display = 'flex';
});

noBtn.addEventListener('click', function (e) {
	logoutDiv.style.display = 'none';
});

yesBtn.addEventListener('click', function (e) {
	chrome.storage.sync.clear(function () {
		console.log(
			'All values are removed from storage.'
		);
	});
	logoutDiv.style.display = 'none';
	checkAuth();
});

const logoutFunc = () => {
	chrome.storage.sync.clear(function () {
		console.log(
			'All values are removed from storage.'
		);
	});
	logoutDiv.style.display = 'none';
	checkAuth();
};

document.addEventListener(
	'DOMContentLoaded',
	() => {
		console.log('DOM loaded');
		checkAuth();
	}
);

let logger = false;

const initScript = () => {
	chrome.runtime.sendMessage(
		{ action: 'checkAuth' },
		(response) => {
			if (response.authenticated) {
				showScreen('loading');
				setTimeout(() => {
					showScreen('main');
				}, 1000);
			} else {
				showScreen('authenticate');
			}
		}
	);
};

const showMsg = (type, msg) => {
	const error = document.getElementById('error');
	if (type === 'error') {
		error.style.color = 'red';
	}
	if (type === 'success') {
		error.style.color = 'green';
	}
	error.innerHTML = msg;
	error.style.display = 'block';
	setTimeout(() => {
		error.style.display = 'none';
	}, 3000);
};

const msgLabel =
	document.getElementById('msgLabel');

document
	.getElementById('externalLink')
	.addEventListener('click', function (event) {
		event.preventDefault();
		chrome.tabs.create({ url: event.target.href });
	});

const showScreen = (screen, msg) => {
	switch (screen) {
		case 'authenticate':
			main.style.display = 'none';
			loading.style.display = 'none';
			authenticate.style.display = 'flex';
			break;

		case 'main':
			loading.style.display = 'none';
			authenticate.style.display = 'none';
			main.style.display = 'flex';

			break;

		case 'loading':
			authenticate.style.display = 'none';
			main.style.display = 'none';
			loading.style.display = 'flex';
			if (msg != undefined) {
				msgLabel.innerHTML = msg;
			} else {
				msgLabel.innerHTML = 'Loading...';
			}
			break;
	}
};

document
	.getElementById('loginButton')
	.addEventListener('click', () => {
		function validateEmail(email) {
			const regex =
				/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
			return regex.test(email);
		}
		const email =
			document.getElementById('email').value;
		const password =
			document.getElementById('password').value;
		if (email === '' || password === '') {
			showMsg(
				'error',
				'Please enter username and password'
			);
			return;
		}
		if (!validateEmail(email)) {
			showMsg('error', 'Invalid email address');
			return;
		}
		chrome.runtime.sendMessage(
			{
				action: 'login',
				email,
				password,
			},
			(response) => {
				if (response.success) {
					checkAuth();
				} else {
					showMsg('error', response.message);
				}
			}
		);
	});

const getCurrentUsername = () => {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(
			{ action: 'checkUsername' },
			(response) => {
				if (
					response &&
					response.data &&
					response.data.data &&
					response.data.data.user &&
					response.data.data.user.reel &&
					response.data.data.user.reel.owner &&
					response.data.data.user.reel.owner.username
				) {
					resolve(
						response.data.data.user.reel.owner.username
					);
				} else {
					reject('Username not found');
				}
			}
		);
	});
};

const checkAuth = () => {
	chrome.runtime.sendMessage(
		{ action: 'getEmail' },
		async (response) => {
			if (response.success) {
				let email = response.email;
				await getCurrentUsername()
					.then((username) => {
						igusername = username;
						usernameLbl.innerHTML = igusername;
					})
					.catch((error) => {
						// console.error(error);
					});
				chrome.runtime.sendMessage(
					{ action: 'extensionEnabled', email },
					async (response) => {
						// console.log(response);
						if (response.success) {
							if (response.usernames.length != 0) {
								if (
									response.usernames.includes(igusername)
								) {
									showScreen('loading');
									setTimeout(() => {
										logger = true;
										output.innerHTML = `Start Fetching!`;
										showScreen('main');
									}, 500);
								} else {
									showScreen('loading');
									setTimeout(() => {
										showScreen('main');
										logger = false;
										output.innerHTML = `Current Instagram Account is not registered!`;
									}, 500);
								}
							}
						} else if (!response.success) {
							showScreen('loading');
							setTimeout(() => {
								logoutFunc();
							}, 500);
						}
					}
				);
			} else {
				showScreen('authenticate');
			}
		}
	);
};

const getEmailFromStorage = () => {
	return new Promise((resolve, reject) => {
		chrome.storage.sync.get(
			['email'],
			function (result) {
				if (result.email === undefined) {
					resolve('');
				} else {
					resolve(result.email);
				}
			}
		);
	});
};

document
	.getElementById('fetchButton')
	.addEventListener('click', async () => {
		rotateIcon();
		if (!logger) {
			output.innerHTML = `Action Not allowed`;
			return;
		}
		output.innerHTML = `Loading...`;
		chrome.runtime.sendMessage(
			{ action: 'fetchData', username: igusername },
			(response) => {
				if (!response.success) {
					output.innerHTML = `Error Occured: Instagram Login Not Found. If Issue persist, Contact Support`;
					return;
				}
				output.innerHTML = `Data Fetched!`;

				followers.innerHTML = formatNum(
					response.data.data.user.edge_followed_by
						.count
				);
				followings.innerHTML = formatNum(
					response.data.data.user.edge_follow.count
				);
				posts.innerHTML = formatNum(
					response.data.data.user
						.edge_owner_to_timeline_media.count
				);
				requests.innerHTML = formatNum(
					response.res.data.users.length
				);
			}
		);
	});

usernameLbl.addEventListener('click', () => {
	chrome.tabs.create({
		url: `https://www.instagram.com/${igusername}`,
	});
});
