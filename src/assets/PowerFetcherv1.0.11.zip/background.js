chrome.runtime.onMessage.addListener(
	(request, sender, sendResponse) => {
		if (request.action === 'fetchData') {
			chrome.cookies.getAll(
				{ url: 'https://www.instagram.com' },
				async function (cookies) {
					let cookieString = '';
					for (let cookie of cookies) {
						cookieString +=
							cookie.name + '=' + cookie.value + '; ';
					}

					let res = {};

					await fetch(
						'https://www.instagram.com/api/v1/friendships/pending/',
						{
							headers: {
								Referer: 'https://www.instagram.com/',
								Origin: 'https://www.instagram.com',
								Cookie: cookieString,
								'X-Ig-App-Id': '936619743392459',
								'User-Agent':
									'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
							},
						}
					)
						.then((response) => response.json())
						.then(
							(data) => (res = { data, success: true })
						)
						.catch(
							(error) =>
								(res = {
									data: error.toString(),
									success: false,
								})
						);

					await fetch(
						`https://www.instagram.com/api/v1/users/web_profile_info/?username=${request.username}`,
						{
							headers: {
								Referer: 'https://www.instagram.com/',
								Origin: 'https://www.instagram.com',
								Cookie: cookieString,
								'X-Ig-App-Id': '936619743392459',
								'User-Agent':
									'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
							},
						}
					)
						.then((response) => response.json())
						.then((data) => {
							sendResponse({ data, res, success: true });
						})
						.catch((error) => {
							console.log(error);
							sendResponse({ error, success: false });
						});
				}
			);
			return true; // Will respond asynchronously.
		}
	}
);

chrome.runtime.onMessage.addListener(
	(request, sender, sendResponse) => {
		if (request.action === 'checkUsername') {
			chrome.cookies.getAll(
				{ url: 'https://www.instagram.com' },
				function (cookies) {
					let cookieString = '';
					let userId = '';
					for (let cookie of cookies) {
						cookieString +=
							cookie.name + '=' + cookie.value + '; ';
						if (cookie.name == 'ds_user_id') {
							userId = cookie.value;
						}
					}
					const variables = {
						include_chaining: true,
						include_highlight_reels: false,
						include_live_status: false,
						include_logged_out_extras: false,
						include_reel: true,
						include_suggested_users: true,
						user_id: userId,
					};
					const baseUrl =
						'https://www.instagram.com/graphql/query/?doc_id=18113378221181848&';

					const queryString = `variables=${encodeURIComponent(
						JSON.stringify(variables)
					)}`;
					const fullUrl = baseUrl + queryString;
					fetch(fullUrl, {
						headers: {
							Cookie: cookieString,
							'X-Ig-App-Id': '936619743392459',
							'User-Agent':
								'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
						},
					})
						.then((response) => response.json())
						.then((data) => sendResponse({ data }))
						.catch((error) =>
							sendResponse({
								error: error.toString(),
								data: null,
							})
						);
				}
			);
			return true; // Will respond asynchronously.
		}
	}
);

chrome.runtime.onMessage.addListener(
	(request, sender, sendResponse) => {
		if (request.action == 'checkAuth') {
			let authenticated = false;
			chrome.storage.sync.get(
				['isAuthenticated'],
				function (result) {
					if (result.isAuthenticated === undefined) {
						chrome.storage.sync.set({
							isAuthenticated: false,
						});
						sendResponse({ authenticated });
						return;
					}
					authenticated = result.isAuthenticated;
					sendResponse({ authenticated });
				}
			);
			return true;
		}
	}
);

chrome.runtime.onMessage.addListener(
	(request, sender, sendResponse) => {
		(async () => {
			if (request.action == 'login') {
				const { email, password } = request;
				const options = {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify({
						email,
						password,
					}),
				};

				try {
					const data = await fetch(
						'https://api.igloaded.com/user/login',
						options
					);
					const response = await data.json();
					if (response.status == 'error') {
						sendResponse({
							success: false,
							message: response.message,
							response: response,
						});
					} else if (response.status == 'ok') {
						if (response.plan.isExtensionEnabled) {
							chrome.storage.sync.set({
								isAuthenticated: true,
								name: response.name,
								email: response.email,
							});
							await chrome.storage.local.set(
								{ token: response.token },
								function () {
									console.log('Token Is set');
								}
							);
							if (
								response.plan.extensionUsernames.length !=
								0
							) {
								chrome.storage.sync.set({
									usernames:
										response.plan.extensionUsernames,
								});
							}
							sendResponse({
								success: true,
								message: 'Successfully Authenticated',
								usernames:
									response.plan.extensionUsernames,
							});
						} else {
							sendResponse({
								success: false,
								message:
									'Use of Extension is not enabled for this account',
							});
						}
					} else {
						sendResponse({
							success: false,
							message: 'Unknown response status',
						});
					}
				} catch (error) {
					sendResponse({
						success: false,
						message: `An error occurred: ${error.message}`,
					});
				}
			}
		})();
		return true;
	}
);

chrome.runtime.onMessage.addListener(
	(request, sender, sendResponse) => {
		if (request.action == 'getEmail') {
			chrome.storage.sync.get(
				['email'],
				function (result) {
					if (result.email === undefined) {
						sendResponse({ success: false, email: '' });
					} else {
						sendResponse({
							success: true,
							email: result.email,
						});
					}
				}
			);
			return true;
		}
	}
);

chrome.runtime.onMessage.addListener(
	(request, sender, sendResponse) => {
		(async () => {
			if (request.action == 'extensionEnabled') {
				const { email } = request;
				let token = '';
				await new Promise((resolve, reject) => {
					chrome.storage.local.get(
						['token'],
						function (result) {
							if (chrome.runtime.lastError) {
								reject(chrome.runtime.lastError);
							} else {
								token = result.token;
								resolve(token);
							}
						}
					);
				});
				const options = {
					method: 'GET',
					credentials: 'include',
					headers: {
						'Content-Type': 'application/json',
						Authorization: `Bearer ${token}`,
						IGL_API_KEY: 'igloadedapp@20242325',
					},
				};
				try {
					const data = await fetch(
						`https://api.igloaded.com/user/getplan?email=${email}`,
						options
					);
					const response = await data.json();
					if (response.status == 'ok') {
						if (response.data.plan.isExtensionEnabled) {
							if (
								response.data.plan.extensionUsernames
									.length != 0
							) {
								chrome.storage.sync.set({
									isAuthenticated: true,
									usernames:
										response.data.plan.extensionUsernames,
								});
								sendResponse({
									success: true,
									usernames:
										response.data.plan.extensionUsernames,
									message:
										'Use of Extension is enabled for this account',
								});
							} else {
								sendResponse({
									success: true,
									message:
										'Empty list of usernames for this account',
								});
							}
						} else {
							sendResponse({
								success: false,
								message:
									'Use of Extension is not enabled for this account',
							});
						}
					} else {
						sendResponse({
							success: false,
							message: response.message,
							response: response,
						});
					}
				} catch (error) {
					sendResponse({
						success: false,
						message: `An error occurred: ${error.message}`,
						error: error,
					});
				}
			}
		})();
		return true;
	}
);
